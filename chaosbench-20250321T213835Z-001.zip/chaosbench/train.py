import torch
import yaml
import pytorch_lightning as pl
from dataset import CSV_ERA5_Dataset
from models.model import S2SBenchmarkModel
import config

# Mount Google Drive
from google.colab import drive
drive.mount('/content/drive')

# Load configuration arguments from YAML
config_filepath = '/content/drive/MyDrive/chaosbench/configs/fno_pinn.yaml'
with open(config_filepath, 'r') as file:
    config_yaml = yaml.safe_load(file)

model_args = config_yaml['model_args']
data_args = config_yaml['data_args']

# Dataset initialization
train_dataset = CSV_ERA5_Dataset(
    years=data_args['train_years'],
    variables=config.PARAMS,
    pressure_levels=config.PRESSURE_LEVELS,
    is_normalized=True
)

val_dataset = CSV_ERA5_Dataset(
    years=data_args['val_years'],
    variables=config.PARAMS,
    pressure_levels=config.PRESSURE_LEVELS,
    is_normalized=True
)

# Data loaders
train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=model_args.get('batch_size', 32), shuffle=True, num_workers=model_args.get('num_workers', 4))
val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=model_args.get('batch_size', 32), num_workers=model_args.get('num_workers', 4))

# Model initialization
model = FNOPINNModel(model_args=model_args, data_args=data_args)
model.setup()

# Lightning trainer setup
trainer = pl.Trainer(
    devices=1,
    accelerator='gpu',
    max_epochs=model_args.get('epochs', 100),
    logger=pl.loggers.TensorBoardLogger(save_dir='/content/drive/MyDrive/ChaosBench/logs'),
    callbacks=[pl.callbacks.ModelCheckpoint(monitor='val_loss', mode='min', dirpath='/content/drive/MyDrive/ChaosBench/checkpoints/')]
)

# Start training
trainer.fit(model, train_dataloaders=train_loader, val_dataloaders=val_loader)
