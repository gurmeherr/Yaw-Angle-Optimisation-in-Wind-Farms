import torch
import pandas as pd
import numpy as np
import xarray as xr
from torch.utils.data import Dataset
from pathlib import Path
import config
from collections import defaultdict

class CSV_ERA5_Dataset(Dataset):
    def __init__(self, years, variables=None, land_vars=None, ocean_vars=None,
                 pressure_levels=config.PRESSURE_LEVELS, is_normalized=True,
                 n_step=None, lead_time=1):
        """
        Loads ERA5 CSV files for the UK region, grouping files by date.
        Each sample is constructed by stacking data for all variables,
        resulting in an array of shape (num_channels, H, W), where:
          - For variables 'z', 't', 'u', 'v': all levels in pressure_levels are used (10 levels each)
          - For variable 'q': only levels [200, 300, 500, 700, 850, 925, 1000] are used (7 levels)
          - For variable 'w': only level [500] is used (1 level)
        Total channels = 10 + 7 + 10 + 10 + 10 + 1 = 48.
        If is_normalized is True, the data is normalized using climatology.
        
        Additionally, this dataset supports iterative forecasting by returning a target sequence of n_step days
        after a lead_time offset.
        
        Parameters:
          years         : list of years (e.g., [2022])
          variables     : list of variables to include. If None and land_vars/ocean_vars are provided,
                          variables is set to land_vars + ocean_vars. Defaults to config.PARAMS.
          land_vars     : optional list of land variables.
          ocean_vars    : optional list of ocean variables.
          pressure_levels: list of pressure levels (default: config.PRESSURE_LEVELS)
          is_normalized : flag to normalize data using climatology.
          n_step        : forecast horizon (number of future steps); if not provided, defaults to config.N_STEPS.
          lead_time     : number of steps to skip before starting the target forecast (default: 1)
        """
        self.data = []
        # Determine the variables to load
        if variables is None:
            if land_vars or ocean_vars:
                self.variables = []
                if land_vars:
                    self.variables.extend(land_vars)
                if ocean_vars:
                    self.variables.extend(ocean_vars)
            else:
                self.variables = config.PARAMS
        else:
            self.variables = variables
            
        self.pressure_levels = pressure_levels
        self.is_normalized = is_normalized
        self.n_step = n_step if n_step is not None else config.N_STEPS
        self.lead_time = lead_time

        # Load climatology from zarr
        climatology = xr.open_zarr('/content/drive/MyDrive/climatology/climatology_era5.zarr')
        climatology_mean = climatology['mean'].values
        climatology_sigma = climatology['sigma'].values
        climatology_params = list(climatology['param'].values)

        # Build a mapping from climatology parameter name to its index
        var_level_to_idx = {param: idx for idx, param in enumerate(climatology_params)}

        # Define expected latitude and longitude grids (9 latitudes, 8 longitudes)
        expected_latitudes = np.linspace(60, 48, 9)
        expected_longitudes = np.array([0.0, 1.5, 3.0, 4.5, 6.0, 7.5, 9.0, 10.5])

        # Group files by date over all years
        files_by_date = defaultdict(dict)
        for year in years:
            year_path = Path(config.DATA_DIR) / 'era5_csv' / str(year)
            files = sorted(year_path.glob('*.csv'))
            for file_path in files:
                parts = file_path.stem.split('_')
                if len(parts) < 2:
                    continue
                var = parts[0]
                date_str = parts[1]
                files_by_date[date_str][var] = file_path

        # For each date, load data for all variables if available
        for date_str, file_dict in sorted(files_by_date.items()):
            # Skip if any variable is missing for the date
            if not all(var in file_dict for var in self.variables):
                continue
            sample_list = []
            valid_sample = True
            for var in self.variables:
                file_path = file_dict[var]
                df = pd.read_csv(file_path)
                # Select pressure levels based on the variable:
                if var == 'q':
                    local_levels = [200, 300, 500, 700, 850, 925, 1000]
                elif var == 'w':
                    local_levels = [500]
                else:
                    local_levels = pressure_levels  # For z, t, u, v use all levels
                # Create an array for this variable: shape (num_levels_for_var, 9, 8)
                var_data = np.zeros((len(local_levels), 9, 8))
                for i, level in enumerate(local_levels):
                    df_level = df[df['level'] == level]
                    if df_level.empty:
                        valid_sample = False
                        break
                    # Pivot the dataframe to form a grid (9, 8)
                    grid = df_level.pivot(index='latitude', columns='longitude', values=var)
                    grid = grid.reindex(index=expected_latitudes, columns=expected_longitudes)
                    # Interpolate missing values and fill any remaining NaNs with 0
                    grid = grid.interpolate(method='linear', axis=0).interpolate(method='linear', axis=1).fillna(0)
                    var_data[i] = grid.values
                if not valid_sample:
                    break
                # Normalize per variable-level if requested
                if is_normalized:
                    for i, level in enumerate(local_levels):
                        key = f"{var}-{level}"
                        if key in var_level_to_idx:
                            idx_clim = var_level_to_idx[key]
                            var_data[i] = (var_data[i] - climatology_mean[idx_clim]) / climatology_sigma[idx_clim]
                sample_list.append(var_data)
            if not valid_sample or len(sample_list) != len(self.variables):
                continue
            # Concatenate along the channel dimension. Final shape: (num_channels, 9, 8)
            daily_sample = np.concatenate(sample_list, axis=0)
            self.data.append(daily_sample)

    def __len__(self):
        # Ensure there are enough future steps for targets: we need lead_time + n_step days after the input sample.
        return max(0, len(self.data) - (self.lead_time + self.n_step) + 1)

    def __getitem__(self, idx):
        # x: the current sample (the "initial condition" for iterative forecasting)
        x = self.data[idx]
        # Build y by stacking the subsequent n_step samples starting after the lead_time offset.
        y_list = []
        for i in range(self.n_step):
            target_idx = idx + self.lead_time + i
            if target_idx < len(self.data):
                y_list.append(self.data[target_idx])
            else:
                # If not enough steps, repeat the last available sample.
                y_list.append(self.data[-1])
        # y has shape (n_step, num_channels, H, W)
        y = np.stack(y_list)
        timestamp = idx  # or use a proper timestamp if available
        x = torch.tensor(x, dtype=torch.float32)
        y = torch.tensor(y, dtype=torch.float32)
        return timestamp, x, y



