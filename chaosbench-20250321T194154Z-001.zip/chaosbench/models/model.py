import os
import torch
torch.autograd.set_detect_anomaly(True)
from torch.utils.data import DataLoader
import pytorch_lightning as pl
import yaml

from models import mlp, cnn, ae, fno, vit
import dataset, config, utils, criterion
from dataset import CSV_ERA5_Dataset
from torch import nn

# Helper function to compute flattened channel index for new stacking order
def get_channel_index(var, level):
    """
    Compute the flattened channel index for a given variable and level
    according to the new stacking:
      - z: all levels in config.PRESSURE_LEVELS  --> base = 0
      - q: levels [200, 300, 500, 700, 850, 925, 1000]  --> base = 10
      - t: all levels in config.PRESSURE_LEVELS  --> base = 10+7 = 17
      - u: all levels in config.PRESSURE_LEVELS  --> base = 10+7+10 = 27
      - v: all levels in config.PRESSURE_LEVELS  --> base = 10+7+10+10 = 37
      - w: level [500]  --> base = 10+7+10+10+10 = 47
    """
    if var == 'z':
        base = 0
        levels = config.PRESSURE_LEVELS
    elif var == 'q':
        base = 10
        levels = [200, 300, 500, 700, 850, 925, 1000]
    elif var == 't':
        base = 10 + 7  # 17
        levels = config.PRESSURE_LEVELS
    elif var == 'u':
        base = 10 + 7 + 10  # 27
        levels = config.PRESSURE_LEVELS
    elif var == 'v':
        base = 10 + 7 + 10 + 10  # 37
        levels = config.PRESSURE_LEVELS
    elif var == 'w':
        base = 10 + 7 + 10 + 10 + 10  # 47
        levels = [500]
    else:
        raise ValueError(f"Unknown variable: {var}")
    return base + levels.index(level)

# Custom Transformer Block from vit.py
class CustomTransformerBlock(nn.Module):
    def __init__(self, dim, heads=4, reduction_ratio=4, ff_expansion=2):
        """
        A residual transformer block that applies efficient self-attention and a feed-forward network.
        :param dim: number of input channels
        :param heads: number of attention heads
        :param reduction_ratio: reduction ratio for key/value downsampling in attention
        :param ff_expansion: expansion factor for the feed-forward network
        """
        super().__init__()
        # PreNorm wraps the function with layer normalization
        self.attn = vit.PreNorm(dim, vit.EfficientSelfAttention(dim=dim, heads=heads, reduction_ratio=reduction_ratio))
        self.ff   = vit.PreNorm(dim, vit.MixFeedForward(dim=dim, expansion_factor=ff_expansion))
        
    def forward(self, x):
        # Residual connection around attention
        x = x + self.attn(x)
        # Residual connection around feed-forward network
        x = x + self.ff(x)
        return x

class S2SBenchmarkModel(pl.LightningModule):

    def __init__(self, model_args, data_args):
        super(S2SBenchmarkModel, self).__init__()
        self.save_hyperparameters()
        
        self.model_args = model_args
        self.data_args = data_args
        
        # Determine input and output sizes (with possible additions from land/ocean vars)
        land_vars = self.data_args.get('land_vars', [])
        ocean_vars = self.data_args.get('ocean_vars', [])
        input_size = self.model_args['input_size'] + len(land_vars) + len(ocean_vars)
        output_size = self.model_args['output_size'] + len(land_vars) + len(ocean_vars)
        
        # Initialize the base FNO model
        if 'fno' in self.model_args['model_name']:
            width = self.model_args['width']
            if isinstance(width, int):
                width = [width] * 5
            elif not isinstance(width, (list, tuple)):
                raise TypeError(f"Expected width to be a list or int, got {type(width)} instead.")
            self.model = fno.FNO2d(
                input_size=input_size,
                modes1=self.model_args['modes1'], 
                modes2=self.model_args['modes2'], 
                width=width,
                initial_step=self.model_args['initial_step']
            )
        
        # Configure custom transformer layers to refine features after FNO.
        transformer_layers = self.model_args.get('transformer_layers', 2)
        transformer_heads = self.model_args.get('transformer_heads', 4)
        reduction_ratio   = self.model_args.get('reduction_ratio', 4)
        ff_expansion      = self.model_args.get('ff_expansion', 2)
        # The transformer layers further refine the FNO output.
        self.transformer = nn.Sequential(*[
            CustomTransformerBlock(dim=output_size,
                                   heads=transformer_heads,
                                   reduction_ratio=reduction_ratio,
                                   ff_expansion=ff_expansion)
            for _ in range(transformer_layers)
        ])
        
        # Initialize physics-informed loss (combined loss always expects full predictions)
        self.loss = self.init_loss_fn()
        
    def setup(self, stage=None):
        # Setup datasets for training/validation.
        if stage == 'fit' or stage is None:
            self.train_dataset = CSV_ERA5_Dataset(
                years=self.data_args['train_years'], 
                variables=self.data_args.get('variables', config.PARAMS),
                pressure_levels=config.PRESSURE_LEVELS,
                is_normalized=True
            )
            self.val_dataset = CSV_ERA5_Dataset(
                years=self.data_args['val_years'], 
                variables=config.PARAMS,
                pressure_levels=config.PRESSURE_LEVELS,
                is_normalized=True
            )
        
    def train_dataloader(self):
        return DataLoader(
            self.train_dataset,
            batch_size=self.data_args['batch_size'],
            shuffle=True,
            num_workers=self.data_args.get('num_workers', 4)
        )

    def val_dataloader(self):
        return DataLoader(
            self.val_dataset,
            batch_size=self.data_args['batch_size'],
            shuffle=False,
            num_workers=self.data_args.get('num_workers', 4)
        )
        
    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(
            self.parameters(),
            lr=self.hparams.model_args['learning_rate'],
            weight_decay=1e-5
        )
    
        scheduler = torch.optim.lr_scheduler.OneCycleLR(
            optimizer,
            max_lr=self.hparams.model_args['learning_rate'],
            steps_per_epoch=self.hparams.model_args['train_steps_per_epoch'],
            epochs=self.hparams.model_args['epochs'],
            pct_start=0.3,
            anneal_strategy='cos',
            final_div_factor=1e4
        )
    
        return {
            'optimizer': optimizer,
            'lr_scheduler': {
                'scheduler': scheduler,
                'interval': 'step',
                'frequency': 1
            }
        }

    def physics_loss(self, preds, x, u, v, z, rho, nu):
        """
        Enforces horizontal physics constraints using:
          (i) Divergence-free condition: ∇·u = du/dx + dv/dy = 0.
          (ii) Momentum conservation (steady state):
              For the x-component:
                residual_x = d(u²)/dx + d(uv)/dy + (1/ρ)*d(p)/dx - ν*(d²u/dx² + d²u/dy²)
              For the y-component:
                residual_y = d(uv)/dx + d(v²)/dy + (1/ρ)*d(p)/dy - ν*(d²v/dx² + d²v/dy²)
          
        Here, pressure is approximated as p = g * z, with g = 9.81 m/s².
        Assumes u, v, and z have shape (B, L, H, W) with L = 10.
        Finite differences are computed using central differences with periodic boundaries.
        """
        g = 9.81  # gravitational acceleration
        
        B, L, H, W = u.shape
        u_r = u.reshape(B * L, H, W)
        v_r = v.reshape(B * L, H, W)
        z_r = z.reshape(B * L, H, W)
        p_r = g * z_r
        
        dx = 1.5
        dy = 1.5
        
        def central_diff(tensor, axis, spacing):
            return (torch.roll(tensor, shifts=-1, dims=axis) - 
                    torch.roll(tensor, shifts=1, dims=axis)) / (2 * spacing)
        
        def second_derivative(tensor, axis, spacing):
            return (torch.roll(tensor, shifts=-1, dims=axis) - 2 * tensor + 
                    torch.roll(tensor, shifts=1, dims=axis)) / (spacing ** 2)
        
        du_dx = central_diff(u_r, axis=2, spacing=dx)
        dv_dy = central_diff(v_r, axis=1, spacing=dy)
        divergence = du_dx + dv_dy
        divergence_loss = torch.nn.functional.mse_loss(divergence, torch.zeros_like(divergence))
        
        u2 = u_r ** 2
        uv = u_r * v_r
        du2_dx = central_diff(u2, axis=2, spacing=dx)
        duv_dy = central_diff(uv, axis=1, spacing=dy)
        dp_dx   = central_diff(p_r, axis=2, spacing=dx)
        d2u_dx2 = second_derivative(u_r, axis=2, spacing=dx)
        d2u_dy2 = second_derivative(u_r, axis=1, spacing=dy)
        residual_x = du2_dx + duv_dy + (1.0 / rho) * dp_dx - nu * (d2u_dx2 + d2u_dy2)
        
        v2 = v_r ** 2
        duv_dx = central_diff(uv, axis=2, spacing=dx)
        dv2_dy = central_diff(v2, axis=1, spacing=dy)
        dp_dy   = central_diff(p_r, axis=1, spacing=dy)
        d2v_dx2 = second_derivative(v_r, axis=2, spacing=dx)
        d2v_dy2 = second_derivative(v_r, axis=1, spacing=dy)
        residual_y = duv_dx + dv2_dy + (1.0 / rho) * dp_dy - nu * (d2v_dx2 + d2v_dy2)
        
        momentum_loss = (torch.nn.functional.mse_loss(residual_x, torch.zeros_like(residual_x)) +
                         torch.nn.functional.mse_loss(residual_y, torch.zeros_like(residual_y)))
        
        return divergence_loss + momentum_loss
    
    def init_loss_fn(self):
        mse_loss = criterion.MSE()
        def combined_loss(preds, target, x):
            # Compute physics loss on full predictions using updated slicing:
            z = preds[:, 0:10, ...]     # geopotential height (channels 0-9)
            u = preds[:, 27:37, ...]    # zonal wind (channels 27-36)
            v = preds[:, 37:47, ...]    # meridional wind (channels 37-46)
            rho, nu = 1.225, 1.5e-5
            physics = self.physics_loss(preds, x, u, v, z, rho, nu)
            return mse_loss(preds, target) + self.model_args['pinn_weight'] * physics
        return combined_loss
    
    def forward(self, x):
        # Get output from FNO.
        out = self.model(x)
        expected_channels = self.model_args['output_size']  # expecting 48 channels
        if out.shape[1] != expected_channels:
            repeat_factor = expected_channels // out.shape[1]
            out = out.repeat(1, repeat_factor, 1, 1)
            out = out[:, :expected_channels, :, :]
        # Refine the FNO features using the custom transformer layers.
        out = self.transformer(out)
        return out
    
    def training_step(self, batch, batch_idx):
        timestamp, x, y = batch
        n_steps = y.size(1)
        loss = 0
        for step_idx in range(n_steps):
            preds = self(x)
            if self.model_args.get('only_headline', False):
                # Compute MSE loss only for headline variables (u and v at 1000 hPa)
                u_idx = get_channel_index('u', 1000)  # index for u at 1000 hPa
                v_idx = get_channel_index('v', 1000)  # index for v at 1000 hPa
                headline_idx = [u_idx, v_idx]
                preds_headline = preds.view(preds.size(0), -1, preds.size(-2), preds.size(-1))[:, headline_idx]
                y_headline = y[:, step_idx].view(y.size(0), -1, y.size(-2), y.size(-1))[:, headline_idx]
                mse_val = criterion.MSE()(preds_headline, y_headline)
                # Compute physics loss on the full predictions
                z = preds[:, 0:10, ...]
                u_full = preds[:, 27:37, ...]
                v_full = preds[:, 37:47, ...]
                rho, nu = 1.225, 1.5e-5
                phys_loss = self.physics_loss(preds, x, u_full, v_full, z, rho, nu)
                step_loss = mse_val + self.model_args['pinn_weight'] * phys_loss
                loss += step_loss
            else:
                loss += self.loss(
                    preds[:, :self.model_args['output_size']],
                    y[:, step_idx, :self.model_args['output_size']],
                    x
                )
            # Autoregressive update: force the input to have 48 channels.
            x = self.forward(preds.detach())
        loss = loss / n_steps
        self.log("train_loss", float(f"{loss:.5e}"), on_step=True, on_epoch=True, prog_bar=True, logger=True)
        return loss
    
    def validation_step(self, batch, batch_idx):
        timestamp, x, y = batch
        n_steps = y.size(1)
        loss = 0
        for step_idx in range(n_steps):
            preds = self(x)
            if self.model_args.get('only_headline', False):
                u_idx = get_channel_index('u', 1000)
                v_idx = get_channel_index('v', 1000)
                headline_idx = [u_idx, v_idx]
                preds_headline = preds.view(preds.size(0), -1, preds.size(-2), preds.size(-1))[:, headline_idx]
                y_headline = y[:, step_idx].view(y.size(0), -1, y.size(-2), y.size(-1))[:, headline_idx]
                mse_val = criterion.MSE()(preds_headline, y_headline)
                z = preds[:, 0:10, ...]
                u_full = preds[:, 27:37, ...]
                v_full = preds[:, 37:47, ...]
                rho, nu = 1.225, 1.5e-5
                phys_loss = self.physics_loss(preds, x, u_full, v_full, z, rho, nu)
                step_loss = mse_val + self.model_args['pinn_weight'] * phys_loss
                loss += step_loss
            else:
                loss += self.loss(
                    preds[:, :self.model_args['output_size']],
                    y[:, step_idx, :self.model_args['output_size']],
                    x
                )
            x = self.forward(preds)
        loss = loss / n_steps
        self.log("val_loss", float(f"{loss:.5e}"), on_step=True, on_epoch=True, prog_bar=True, logger=True)
        return loss
